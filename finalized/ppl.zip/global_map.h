#ifndef __GLOBAL_MAP_H__
#define __GLOBAL_MAP_H__

#include "grammar.h"
#include "hashmap.h"

extern hashmap non_terminals;
extern hashmap terminals;

#endif
